create database Cons;
use Cons;

create table Console(
id int auto_increment primary key,
ano varchar(250),
est varchar(250),
pre decimal(16,2),
marc varchar(250),
mode varchar(250),
anexo varchar(250));

select * from Console;
